package ShoppingState;

import javax.swing.*;

public abstract class Shelf extends JPanel {
    Shelf next;
    Shelf previous;
}
