package ShoppingState;

import ReadyState.ReadyPage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class bagButton extends JLabel {
    boolean pressed = false;
    JTextArea textArea = new JTextArea();
    public JScrollPane List = new JScrollPane(textArea);
    public void bagList(JFrame frame, ReadyPage readyPage) {
        List.setEnabled(false);
        List.setVisible(false);
        List.setBounds(0, frame.getHeight()*17/30, frame.getHeight()/5, frame.getHeight()*3/10);

        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setFont(new Font("Lucida Handwriting", Font.BOLD | Font.ITALIC, 17));
        textArea.setOpaque(false);
        textArea.setEditable(false);

        textArea.setText(readyPage.bag.textArea.getText());
        List.add(textArea);

        List.setViewportView(textArea);
        List.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        List.getViewport().setOpaque(false);

        ImageIcon listBG = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\ShoppingState\\BagList.png").getImage().getScaledInstance(frame.getHeight()/5, frame.getHeight()*3/10, Image.SCALE_SMOOTH));
        JLabel listBGLabel = new JLabel(listBG);
        listBGLabel.setBounds(0, 0, List.getWidth(), List.getHeight());
        List.add(listBGLabel);
    }
    public bagButton(JFrame frame, ReadyPage readyPage) {
        frame.add(List);
        ImageIcon stable = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\ShoppingState\\BagIcon.png").getImage().getScaledInstance(frame.getHeight()/15, frame.getHeight()/15, Image.SCALE_SMOOTH));
        ImageIcon unstable = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\ShoppingState\\BagIconPress.png").getImage().getScaledInstance(frame.getHeight()/15, frame.getHeight()/15, Image.SCALE_SMOOTH));
        setIcon(stable);
        setBounds(frame.getHeight()/15, frame.getHeight()*13/15, stable.getIconWidth(), stable.getIconHeight());
        bagList(frame, readyPage);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setIcon(unstable);
            }
            public void mouseExited(MouseEvent e) {
                if(!pressed) setIcon(stable);
            }
            public void mousePressed(MouseEvent e) {
                if (pressed) {
                    pressed = false;
                    setIcon(stable);
                    List.setEnabled(false);
                    List.setVisible(false);
                } else{
                    pressed = true;
                    setIcon(unstable);
                    List.setEnabled(true);
                    List.setVisible(true);
                }
            }
        });
    }
}
