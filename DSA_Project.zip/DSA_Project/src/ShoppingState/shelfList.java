package ShoppingState;

import ReadyState.ReadyPage;
import ReadyState.Status;
import PayingState.Queue;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

public class shelfList {
    Shelf first;
    Shelf current;
    void insert(Shelf shelf) {
        if(first==null) {
            first=shelf;
            first.next=first;
            first.previous=first;
        }
        else {
            shelf.previous=first.previous;
            shelf.next=first;
            first.previous.next=shelf;
            first.previous=shelf;
            first=first.previous;
        }
        current=first;
    }
    fruitShelf fruitShelf;
    checkOut checkOut;
    void initial(JFrame frame) {
        insert(fruitShelf = new fruitShelf(frame, this));
        frame.add(first);
        first.setEnabled(false);
        first.setVisible(false);

        insert(checkOut = new checkOut(frame, this));
        frame.add(first);
        first.setEnabled(true);
        first.setVisible(true);
    }
    Status status;
    JLabel dayLabel;
    JLabel enthusiasmLabel;
    JLabel budgetLabel;
    JLabel nextLabel = new JLabel();
    JLabel previousLabel = new JLabel();
    public cartButton cartButton;
    taskButton taskButton;
    bagButton bagButton;
    void updateLabels() {
        dayLabel.setText("Day: " + status.day);
        enthusiasmLabel.setText("<html>Enthusiasm<br>&nbsp;&nbsp;" + Math.round(status.enthusiasm) + "</html>");
        budgetLabel.setText("<html><div style='text-align: right;'>Budget<br>" + (double) Math.round(status.budget * 100) / 100 + "&nbsp;&nbsp;</html>");
    }
    void addStatus(JFrame frame, ReadyPage page) {
        status=page.status;
        dayLabel = new JLabel();
        dayLabel.setFont(new Font("Lucida Handwriting", Font.BOLD, 58));
        dayLabel.setBounds(100, 0, frame.getWidth() / 4, frame.getHeight() * 2 / 21);

        enthusiasmLabel = new JLabel();
        enthusiasmLabel.setFont(new Font("Lucida Handwriting", Font.BOLD | Font.ITALIC, 58));
        enthusiasmLabel.setForeground(new Color(17, 249, 237));
        enthusiasmLabel.setBounds(50, frame.getHeight() * 2 / 21, frame.getWidth() / 4, frame.getHeight() * 4 / 21);

        budgetLabel = new JLabel();
        budgetLabel.setFont(new Font("Lucida Handwriting", Font.BOLD | Font.ITALIC, 58));
        budgetLabel.setForeground(new Color(17, 249, 237));
        budgetLabel.setBounds(frame.getWidth() * 3 / 4, frame.getHeight() * 2 / 21, frame.getWidth() / 4, frame.getHeight() * 4 / 21);

        updateLabels();
        frame.add(dayLabel);
        frame.add(enthusiasmLabel);
        frame.add(budgetLabel);
    }
    void addButton(JFrame frame, ReadyPage readyPage) {
        taskButton=new taskButton(frame, readyPage);
        frame.add(taskButton);
        bagButton=new bagButton(frame, readyPage);
        frame.add(bagButton);
        cartButton=new cartButton(frame);
        cartButton.itemHashTable.loadGoods();
        frame.add(cartButton);
    }
    ReadyPage readyPage;
    public shelfList(JFrame frame, ReadyPage readyPage) {
        this.readyPage=readyPage;
        addStatus(frame, readyPage);
        addButton(frame, readyPage);

        ImageIcon nextStable = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\ShoppingState\\Next.png").getImage().getScaledInstance(frame.getHeight()*2/15, frame.getHeight()*2/15, Image.SCALE_SMOOTH));
        ImageIcon nextUnstable = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\ShoppingState\\NextPress.png").getImage().getScaledInstance(frame.getHeight()*2/15, frame.getHeight()*2/15, Image.SCALE_SMOOTH));;
        ImageIcon previousStable = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\ShoppingState\\Previous.png").getImage().getScaledInstance(frame.getHeight()*2/15, frame.getHeight()*2/15, Image.SCALE_SMOOTH));;
        ImageIcon previousUnstable = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\ShoppingState\\PreviousPress.png").getImage().getScaledInstance(frame.getHeight()*2/15, frame.getHeight()*2/15, Image.SCALE_SMOOTH));;

        nextLabel.setIcon(nextStable);
        nextLabel.setBounds(frame.getWidth()-frame.getHeight()*2/15, frame.getHeight()*11/15, nextStable.getIconWidth(), nextStable.getIconHeight());
        previousLabel.setIcon(previousStable);
        previousLabel.setBounds(0, frame.getHeight()*11/15, previousStable.getIconWidth(), previousStable.getIconHeight());

        frame.add(nextLabel);
        frame.add(previousLabel);
        initial(frame);
        frame.revalidate();
        frame.repaint();

        nextLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                nextLabel.setIcon(nextUnstable);
            }
            public void mouseExited(MouseEvent e) {
                nextLabel.setIcon(nextStable);
            }
            public void mousePressed(MouseEvent e) {
                current.setEnabled(false);
                current.setVisible(false);
                current=current.next;
                current.setEnabled(true);
                current.setVisible(true);
            }
        });
        previousLabel.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                previousLabel.setIcon(previousUnstable);
            }
            public void mouseExited(MouseEvent e) {
                previousLabel.setIcon(previousStable);
            }
            public void mousePressed(MouseEvent e) {
                current.setEnabled(false);
                current.setVisible(false);
                current=current.previous;
                current.setEnabled(true);
                current.setVisible(true);
            }
        });
    }
}
class checkOut extends Shelf{
    checkOut(JFrame frame, shelfList shelfList) {
        setBounds(frame.getBounds());
        setLayout(null);
        add(new exitButton(frame, shelfList));

        ImageIcon BG = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\ShoppingState\\CheckOut.png").getImage().getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH));
        JLabel label = new JLabel(BG);
        label.setBounds(getBounds());
        add(label);
    }
}
class exitButton extends JLabel{
    exitButton(JFrame frame, shelfList shelfList) {
        ImageIcon stable = new ImageIcon("D:\\DSA_Project\\src\\ShoppingState\\Exit.png");
        ImageIcon unstable = new ImageIcon("D:\\DSA_Project\\src\\ShoppingState\\ExitPress.png");
        setIcon(stable);
        setBounds(frame.getWidth()/2-stable.getIconWidth()/2, frame.getHeight()*4/5-stable.getIconHeight()/2, stable.getIconWidth(), stable.getIconHeight());

        addMouseListener(new MouseAdapter() {
           public void mouseEntered(MouseEvent e) {
               setIcon(unstable);
           }
           public void mouseExited(MouseEvent e) {
               setIcon(stable);
           }
           public void mousePressed(MouseEvent e) {
               frame.remove(shelfList.dayLabel);
               frame.remove(shelfList.enthusiasmLabel);
               frame.remove(shelfList.budgetLabel);
               frame.remove(shelfList.nextLabel);
               frame.remove(shelfList.previousLabel);

               frame.remove(shelfList.cartButton);
               frame.remove(shelfList.cartButton.List);
               frame.remove(shelfList.taskButton);
               frame.remove(shelfList.taskButton.List);
               frame.remove(shelfList.bagButton);
               frame.remove(shelfList.bagButton.List);

               frame.remove(shelfList.checkOut);
               frame.remove(shelfList.fruitShelf);
               frame.revalidate();
               frame.repaint();
               frame.add(new Queue(frame, shelfList.readyPage, shelfList));
           }
        });
    }
}

class fruitShelf extends Shelf{
    fruitShelf(JFrame frame, shelfList shelfList) {
        setBounds(frame.getBounds());
        setLayout(null);

        for(int i=1; i<=shelfList.cartButton.itemHashTable.getItem(1).quantity; i++) {
            new appleIcon(this, shelfList);
        }
        for(int i=1; i<=shelfList.cartButton.itemHashTable.getItem(2).quantity; i++) {
            new bananaIcon(this, shelfList);
        }
        for(int i=1; i<=shelfList.cartButton.itemHashTable.getItem(3).quantity; i++) {
            new blueberriesIcon(this, shelfList);
        }
        for(int i=1; i<=shelfList.cartButton.itemHashTable.getItem(4).quantity; i++) {
            new grapesIcon(this, shelfList);
        }
        for(int i=1; i<=shelfList.cartButton.itemHashTable.getItem(5).quantity; i++) {
            new kiwiIcon(this, shelfList);
        }
        for(int i=1; i<=shelfList.cartButton.itemHashTable.getItem(6).quantity; i++) {
            new mangoIcon(this, shelfList);
        }
        for(int i=1; i<=shelfList.cartButton.itemHashTable.getItem(7).quantity; i++) {
            new orangeIcon(this, shelfList);
        }
        for(int i=1; i<=shelfList.cartButton.itemHashTable.getItem(8).quantity; i++) {
            new pineappleIcon(this, shelfList);
        }
        for(int i=1; i<=shelfList.cartButton.itemHashTable.getItem(9).quantity; i++) {
            new strawberriesIcon(this, shelfList);
        }
        for(int i=1; i<=shelfList.cartButton.itemHashTable.getItem(10).quantity; i++) {
            new watermelonIcon(this, shelfList);
        }

        ImageIcon BG = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\ShoppingState\\FruitShelf.png").getImage().getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH));
        JLabel label = new JLabel(BG);
        label.setBounds(getBounds());
        add(label);
    }
}
class appleIcon extends JLabel{
    appleIcon(fruitShelf fruitShelf, shelfList shelfList) {
        ImageIcon icon = new ImageIcon("D:\\DSA_Project\\src\\Item\\Apple.png");
        setIcon(icon);
        Random rand = new Random();
        setBounds(fruitShelf.getWidth()*4/25+rand.nextInt(fruitShelf.getWidth()*7/25-icon.getIconWidth()), fruitShelf.getHeight()/5+rand.nextInt(fruitShelf.getHeight()/5-icon.getIconHeight()), icon.getIconWidth(), icon.getIconHeight());
        fruitShelf.add(this);
        addMouseListener(new MouseAdapter() {
           public void mousePressed(MouseEvent e) {
               if(shelfList.status.budget>=shelfList.cartButton.itemHashTable.getPrice(1)) {
                   setEnabled(false);
                   setVisible(false);
                   shelfList.status.budget-=shelfList.cartButton.itemHashTable.getPrice(1);
                   shelfList.budgetLabel.setText("<html><div style='text-align: right;'>Budget<br>" + (double) Math.round(shelfList.status.budget * 100) / 100 + "&nbsp;&nbsp;</html>");
                   shelfList.cartButton.itemHashTable.getItem(1).have++;
                   shelfList.cartButton.text();
               }
           }
        });
    }
}
class bananaIcon extends JLabel{
    bananaIcon(fruitShelf fruitShelf, shelfList shelfList) {
        ImageIcon icon = new ImageIcon("D:\\DSA_Project\\src\\Item\\Banana.png");
        setIcon(icon);
        Random rand = new Random();
        setBounds(fruitShelf.getWidth()*11/25+rand.nextInt(fruitShelf.getWidth()*7/25-icon.getIconWidth()), fruitShelf.getHeight()/5+rand.nextInt(fruitShelf.getHeight()/5-icon.getIconHeight()), icon.getIconWidth(), icon.getIconHeight());
        fruitShelf.add(this);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if(shelfList.status.budget>=shelfList.cartButton.itemHashTable.getPrice(2)) {
                    setEnabled(false);
                    setVisible(false);
                    shelfList.status.budget-=shelfList.cartButton.itemHashTable.getPrice(2);
                    shelfList.budgetLabel.setText("<html><div style='text-align: right;'>Budget<br>" + (double) Math.round(shelfList.status.budget * 100) / 100 + "&nbsp;&nbsp;</html>");
                    shelfList.cartButton.itemHashTable.getItem(2).have++;
                    shelfList.cartButton.text();
                }
            }
        });
    }
}
class blueberriesIcon extends JLabel{
    blueberriesIcon(fruitShelf fruitShelf, shelfList shelfList) {
        ImageIcon icon = new ImageIcon("D:\\DSA_Project\\src\\Item\\Blueberries.png");
        setIcon(icon);
        Random rand = new Random();
        setBounds(fruitShelf.getWidth()*18/25+rand.nextInt(fruitShelf.getWidth()*7/25-icon.getIconWidth()), fruitShelf.getHeight()/5+rand.nextInt(fruitShelf.getHeight()/5-icon.getIconHeight()), icon.getIconWidth(), icon.getIconHeight());
        fruitShelf.add(this);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if(shelfList.status.budget>=shelfList.cartButton.itemHashTable.getPrice(3)) {
                    setEnabled(false);
                    setVisible(false);
                    shelfList.status.budget-=shelfList.cartButton.itemHashTable.getPrice(3);
                    shelfList.budgetLabel.setText("<html><div style='text-align: right;'>Budget<br>" + (double) Math.round(shelfList.status.budget * 100) / 100 + "&nbsp;&nbsp;</html>");
                    shelfList.cartButton.itemHashTable.getItem(3).have++;
                    shelfList.cartButton.text();
                }
            }
        });
    }
}
class grapesIcon extends JLabel{
    grapesIcon(fruitShelf fruitShelf, shelfList shelfList) {
        ImageIcon icon = new ImageIcon("D:\\DSA_Project\\src\\Item\\Grapes.png");
        setIcon(icon);
        Random rand = new Random();
        setBounds(fruitShelf.getWidth()*4/25+rand.nextInt(fruitShelf.getWidth()*7/25-icon.getIconWidth()), fruitShelf.getHeight()*2/5+rand.nextInt(fruitShelf.getHeight()/5-icon.getIconHeight()), icon.getIconWidth(), icon.getIconHeight());
        fruitShelf.add(this);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if(shelfList.status.budget>=shelfList.cartButton.itemHashTable.getPrice(4)) {
                    setEnabled(false);
                    setVisible(false);
                    shelfList.status.budget-=shelfList.cartButton.itemHashTable.getPrice(4);
                    shelfList.budgetLabel.setText("<html><div style='text-align: right;'>Budget<br>" + (double) Math.round(shelfList.status.budget * 100) / 100 + "&nbsp;&nbsp;</html>");
                    shelfList.cartButton.itemHashTable.getItem(4).have++;
                    shelfList.cartButton.text();
                }
            }
        });
    }
}
class kiwiIcon extends JLabel{
    kiwiIcon(fruitShelf fruitShelf, shelfList shelfList) {
        ImageIcon icon = new ImageIcon("D:\\DSA_Project\\src\\Item\\Kiwi.png");
        setIcon(icon);
        Random rand = new Random();
        setBounds(fruitShelf.getWidth()*11/25+rand.nextInt(fruitShelf.getWidth()*7/25-icon.getIconWidth()), fruitShelf.getHeight()*2/5+rand.nextInt(fruitShelf.getHeight()/5-icon.getIconHeight()), icon.getIconWidth(), icon.getIconHeight());
        fruitShelf.add(this);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if(shelfList.status.budget>=shelfList.cartButton.itemHashTable.getPrice(5)) {
                    setEnabled(false);
                    setVisible(false);
                    shelfList.status.budget-=shelfList.cartButton.itemHashTable.getPrice(5);
                    shelfList.budgetLabel.setText("<html><div style='text-align: right;'>Budget<br>" + (double) Math.round(shelfList.status.budget * 100) / 100 + "&nbsp;&nbsp;</html>");
                    shelfList.cartButton.itemHashTable.getItem(5).have++;
                    shelfList.cartButton.text();
                }
            }
        });
    }
}
class mangoIcon extends JLabel{
    mangoIcon(fruitShelf fruitShelf, shelfList shelfList){
        ImageIcon icon = new ImageIcon("D:\\DSA_Project\\src\\Item\\Mango.png");
        setIcon(icon);
        Random rand = new Random();
        setBounds(fruitShelf.getWidth()*18/25+rand.nextInt(fruitShelf.getWidth()*7/25-icon.getIconWidth()), fruitShelf.getHeight()*2/5+rand.nextInt(fruitShelf.getHeight()/5-icon.getIconHeight()), icon.getIconWidth(), icon.getIconHeight());
        fruitShelf.add(this);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if(shelfList.status.budget>=shelfList.cartButton.itemHashTable.getPrice(6)) {
                    setEnabled(false);
                    setVisible(false);
                    shelfList.status.budget-=shelfList.cartButton.itemHashTable.getPrice(6);
                    shelfList.budgetLabel.setText("<html><div style='text-align: right;'>Budget<br>" + (double) Math.round(shelfList.status.budget * 100) / 100 + "&nbsp;&nbsp;</html>");
                    shelfList.cartButton.itemHashTable.getItem(6).have++;
                    shelfList.cartButton.text();
                }
            }
        });
    }
}
class orangeIcon extends JLabel{
    orangeIcon(fruitShelf fruitShelf, shelfList shelfList) {
        ImageIcon icon = new ImageIcon("D:\\DSA_Project\\src\\Item\\Orange.png");
        setIcon(icon);
        Random rand = new Random();
        setBounds(fruitShelf.getWidth()*4/25+rand.nextInt(fruitShelf.getWidth()*7/25-icon.getIconWidth()), fruitShelf.getHeight()*3/5+rand.nextInt(fruitShelf.getHeight()/5-icon.getIconHeight()), icon.getIconWidth(), icon.getIconHeight());
        fruitShelf.add(this);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if(shelfList.status.budget>=shelfList.cartButton.itemHashTable.getPrice(7)) {
                    setEnabled(false);
                    setVisible(false);
                    shelfList.status.budget-=shelfList.cartButton.itemHashTable.getPrice(7);
                    shelfList.budgetLabel.setText("<html><div style='text-align: right;'>Budget<br>" + (double) Math.round(shelfList.status.budget * 100) / 100 + "&nbsp;&nbsp;</html>");
                    shelfList.cartButton.itemHashTable.getItem(7).have++;
                    shelfList.cartButton.text();
                }
            }
        });
    }
}
class pineappleIcon extends JLabel{
    pineappleIcon(fruitShelf fruitShelf, shelfList shelfList) {
        ImageIcon icon = new ImageIcon("D:\\DSA_Project\\src\\Item\\Pineapple.png");
        setIcon(icon);
        Random rand = new Random();
        setBounds(fruitShelf.getWidth()*11/25+rand.nextInt(fruitShelf.getWidth()*7/25-icon.getIconWidth()), fruitShelf.getHeight()*3/5+rand.nextInt(fruitShelf.getHeight()/5-icon.getIconHeight()), icon.getIconWidth(), icon.getIconHeight());
        fruitShelf.add(this);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if(shelfList.status.budget>=shelfList.cartButton.itemHashTable.getPrice(8)) {
                    setEnabled(false);
                    setVisible(false);
                    shelfList.status.budget-=shelfList.cartButton.itemHashTable.getPrice(8);
                    shelfList.budgetLabel.setText("<html><div style='text-align: right;'>Budget<br>" + (double) Math.round(shelfList.status.budget * 100) / 100 + "&nbsp;&nbsp;</html>");
                    shelfList.cartButton.itemHashTable.getItem(8).have++;
                    shelfList.cartButton.text();
                }
            }
        });
    }
}
class strawberriesIcon extends JLabel{
    strawberriesIcon(fruitShelf fruitShelf, shelfList shelfList) {
        ImageIcon icon = new ImageIcon("D:\\DSA_Project\\src\\Item\\Strawberries.png");
        setIcon(icon);
        Random rand = new Random();
        setBounds(fruitShelf.getWidth()*18/25+rand.nextInt(fruitShelf.getWidth()*7/25-icon.getIconWidth()), fruitShelf.getHeight()*3/5+rand.nextInt(fruitShelf.getHeight()/5-icon.getIconHeight()), icon.getIconWidth(), icon.getIconHeight());
        fruitShelf.add(this);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if(shelfList.status.budget>=shelfList.cartButton.itemHashTable.getPrice(9)) {
                    setEnabled(false);
                    setVisible(false);
                    shelfList.status.budget-=shelfList.cartButton.itemHashTable.getPrice(9);
                    shelfList.budgetLabel.setText("<html><div style='text-align: right;'>Budget<br>" + (double) Math.round(shelfList.status.budget * 100) / 100 + "&nbsp;&nbsp;</html>");
                    shelfList.cartButton.itemHashTable.getItem(9).have++;
                    shelfList.cartButton.text();
                }
            }
        });
    }
}
class watermelonIcon extends JLabel{
    watermelonIcon(fruitShelf fruitShelf, shelfList shelfList){
        ImageIcon icon = new ImageIcon("D:\\DSA_Project\\src\\Item\\Watermelon.png");
        setIcon(icon);
        Random rand = new Random();
        setBounds(rand.nextInt(fruitShelf.getWidth()*4/25-icon.getIconWidth()), fruitShelf.getHeight()/5+rand.nextInt(fruitShelf.getHeight()*3/5-icon.getIconHeight()), icon.getIconWidth(), icon.getIconHeight());
        fruitShelf.add(this);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if(shelfList.status.budget>=shelfList.cartButton.itemHashTable.getPrice(10)) {
                    setEnabled(false);
                    setVisible(false);
                    shelfList.status.budget-=shelfList.cartButton.itemHashTable.getPrice(10);
                    shelfList.budgetLabel.setText("<html><div style='text-align: right;'>Budget<br>" + (double) Math.round(shelfList.status.budget * 100) / 100 + "&nbsp;&nbsp;</html>");
                    shelfList.cartButton.itemHashTable.getItem(10).have++;
                    shelfList.cartButton.text();
                }
            }
        });
    }
}