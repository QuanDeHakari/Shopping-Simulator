package JFrame;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ExitButton extends JLabel {
    private ImageIcon stable = new ImageIcon("D:\\DSA_Project\\src\\Photo\\exitButton.png");
    private ImageIcon unStable = new ImageIcon("D:\\DSA_Project\\src\\Photo\\exitButtonPress.png");
    public ExitButton(JFrame frame) {
        setIcon(stable);
        setBounds((frame.getWidth()-stable.getIconWidth())/2, 600, 400, 200);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                setIcon(unStable);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                setIcon(stable);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                frame.dispose();
            }
        });
    }
}
