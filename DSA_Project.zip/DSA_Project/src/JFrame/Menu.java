package JFrame;

import javax.swing.*;
import java.awt.*;

public class Menu extends JPanel {
    private ImageIcon bgImage;
    private ImageIcon tImage;
    private JLabel background = new JLabel();
    private JLabel title = new JLabel();
    public Menu(JFrame frame) {
        setLayout(null);
        setBounds(0, 0, frame.getWidth(), frame.getHeight());

        bgImage = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\Photo\\Main_Menu.png").getImage().getScaledInstance(frame.getWidth(),frame.getHeight(), Image.SCALE_AREA_AVERAGING));
        tImage = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\Photo\\Tittle.png").getImage().getScaledInstance(frame.getWidth()/2,400, Image.SCALE_SMOOTH));

        background.setIcon(bgImage);
        title.setIcon(tImage);

        background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        title.setBounds((frame.getWidth() - tImage.getIconWidth()) / 2, 0, tImage.getIconWidth(), 400);

        PlayButton playButton = new PlayButton(frame, this);
        add(playButton);
        ExitButton exitButton = new ExitButton(frame);
        add(exitButton);

        add(title);
        add(background);
    }
}
