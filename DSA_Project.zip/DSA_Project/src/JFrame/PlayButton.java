package JFrame;

import ReadyState.ReadyPage;

import javax.swing.*;
import java.awt.event.*;

public class PlayButton extends JLabel {
    private ImageIcon stable = new ImageIcon("D:\\DSA_Project\\src\\Photo\\playButton.png");
    private ImageIcon unStable = new ImageIcon("D:\\DSA_Project\\src\\Photo\\playButtonPress.png");
    public PlayButton(JFrame frame, Menu menu) {
        setIcon(stable);
        setBounds((frame.getWidth()-stable.getIconWidth())/2, 400, 400, 200);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                setIcon(unStable);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                setIcon(stable);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                frame.remove(menu);
                frame.add(new ReadyPage(frame));

                frame.revalidate();
                frame.repaint();
            }
        });
    }
}
