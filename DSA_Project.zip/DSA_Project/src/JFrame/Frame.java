package JFrame;

import javax.swing.*;

public class Frame {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setTitle("Shopping simulator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setLayout(null);

        Menu menu = new Menu(frame);
        frame.add(menu);
        frame.revalidate();
        frame.repaint();
    }
}
