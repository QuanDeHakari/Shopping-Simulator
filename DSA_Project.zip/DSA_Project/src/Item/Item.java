package Item;

import java.util.Random;

public abstract class Item {
    public String name;
    public double price;
    public int quantity;
    public int ID;
    public int need;
    public int have;
    public Item next;
    Random rand=new Random();
    public void loadQuantity(){
        quantity=30;
        int temp = rand.nextInt(9);
        if(temp<2) quantity=0;
        else if(temp<4) quantity+= rand.nextInt(10);
        else if(temp<8) quantity-= rand.nextInt(20);
    }
    public void makePrice() {
        if(quantity!=0) {
            price=price+(quantity>30?(-price*quantity/100):price*(1- (double) quantity /30));
        }
    }
    public abstract Item cloning();
}
