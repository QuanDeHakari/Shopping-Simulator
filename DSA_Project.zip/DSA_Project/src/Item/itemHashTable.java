package Item;

class itemHTList {
    private Item first;
    public itemHTList() {
        first = null;
    }
    public void insert(Item item) {
        int key = item.ID;
        Item previous = null;
        Item current = first;
        while (current != null&&key>current.ID) {
            previous = current;
            current = current.next;
        }
        if (previous==null)
            first = item;
        else previous.next = item;
        item.next = current;
    }
    public double getPrice(int key) {
        Item current = first;
        while (current != null) {
            if (current.ID == key) return current.price;
            current = current.next;
        }
        return 0;
    }
    public Item find(int key) {
        Item current = first;
        while (current != null) {
            if (current.ID == key) return current;
            current = current.next;
        }
        return null;
    }
    public String addText() {
        Item current = first;
        StringBuilder result = new StringBuilder();
        while (current != null) {
            if(current.have!=0) result.append(current.have).append(" ").append(current.name).append("\n");
            current = current.next;
        }
        return result.toString();
    }
    public void loadGoods(){
        Item current = first;
        while (current != null) {
            current.loadQuantity();
            current.makePrice();
            current = current.next;
        }
    }
}
public class itemHashTable {
    public int size = 101;
    public itemHTList[] Array = new itemHTList[size];
    public itemHashTable() {
        for (int i = 0; i < size; i++)
            Array[i] = new itemHTList();
        initial();
    }
    int hashFunc(int key){
        return key%size;
    }
    public void insert(Item item) {
        int hashVal = hashFunc(item.ID);
        Array[hashVal].insert(item);
    }
    public double getPrice(int key) {
        int hashVal = hashFunc(key);
        return Array[hashVal].getPrice(key);
    }
    public Item getItem(int key) {
        int hashVal = hashFunc(key);
        return Array[hashVal].find(key);
    }
    public String addText(int hashVal) {
        return Array[hashVal].addText();
    }
    public void loadGoods(){
        for(int i = 0; i<size; i++)
            Array[i].loadGoods();
    }
    
    public void initial() {
        insert(new Apple());
        insert(new Banana());
        insert(new Blueberries());
        insert(new Grapes());
        insert(new Kiwi());
        insert(new Mango());
        insert(new Orange());
        insert(new Pineapple());
        insert(new Strawberries());
        insert(new Watermelon());
    }
}

class Apple extends Item {
    Apple() {
        name = "Apple";
        price = 0.4;
        ID = 1;
    }
    public Item cloning(){
        Apple clone = new Apple();
        clone.need= rand.nextInt(2)+1;
        return clone;
    }
}
class Banana extends Item {
    Banana() {
        name = "Banana";
        price = 0.5;
        ID = 2;
    }
    public Item cloning(){
        Banana clone = new Banana();
        clone.need= rand.nextInt(2)+1;
        return clone;
    }
}
class Blueberries extends Item {
    Blueberries() {
        name = "Blueberries";
        price = 2;
        ID = 3;
    }
    public Item cloning(){
        Blueberries clone = new Blueberries();
        clone.need=rand.nextInt(2)+1;
        return clone;
    }
}
class Grapes extends Item {
    Grapes() {
        name = "Grapes";
        price = 3.2;
        ID = 4;
    }
    public Item cloning(){
        Grapes clone = new Grapes();
        clone.need= rand.nextInt(2)+1;
        return clone;
    }
}
class Kiwi extends Item {
    Kiwi() {
        name = "Kiwi";
        price = 1.5;
        ID = 5;
    }
    public Item cloning(){
        Kiwi clone = new Kiwi();
        clone.need= rand.nextInt(2)+1;
        return clone;
    }
}
class Mango extends Item {
    Mango() {
        name = "Mango";
        price = 0.7;
        ID = 6;
    }
    public Item cloning(){
        Mango clone = new Mango();
        clone.need= rand.nextInt(2)+1;
        return clone;
    }
}
class Orange extends Item {
    Orange() {
        name = "Orange";
        price = 1.3;
        ID = 7;
    }
    public Item cloning(){
        Orange clone = new Orange();
        clone.need= rand.nextInt(2)+1;
        return clone;
    }
}
class Pineapple extends Item {
    Pineapple() {
        name = "Pineapple";
        price = 1.5;
        ID = 8;
    }
    public Item cloning(){
        Pineapple clone = new Pineapple();
        clone.need=rand.nextInt(2)+1;
        return clone;
    }
}
class Strawberries extends Item {
    Strawberries() {
        name = "Strawberries";
        price = 2.8;
        ID = 9;
    }
    public Item cloning(){
        Strawberries clone = new Strawberries();
        clone.need=rand.nextInt(2)+1;
        return clone;
    }
}
class Watermelon extends Item {
    Watermelon() {
        name = "Watermelon";
        price = 1;
        ID = 10;
    }
    public Item cloning(){
        Watermelon clone = new Watermelon();
        clone.need=rand.nextInt(2)+1;
        return clone;
    }
}