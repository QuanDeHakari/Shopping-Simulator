package Item;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class Task extends JScrollPane {
    itemHashTable itemHashTable = new itemHashTable();
    public Item first;
    public JTextArea textArea = new JTextArea();

    public void reNew() {
        first = null;
        int i = 1;
        while (i <= 10) {
            boolean temp = new Random().nextBoolean();
            if (temp) insert(itemHashTable.getItem(i).cloning());
            i += new Random().nextInt(3) + 1;
        }

        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setFont(new Font("Lucida Handwriting", Font.BOLD | Font.ITALIC, 29));
        textArea.setOpaque(false);

        StringBuilder textBuilder = new StringBuilder();
        Item current = first;
        while (current != null) {
            textBuilder.append(current.need).append(" ").append(current.name).append("\n");
            current = current.next;
        }
        textArea.setText(textBuilder.toString());
        add(textArea);

        setViewportView(textArea);
        setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        setOpaque(false);
        getViewport().setOpaque(false);
    }

    void insert(Item item) {
        Item previous = null;
        Item current = first;
        while (current != null) {
            previous = current;
            current = current.next;
        }
        if (previous == null) {
            first = item;
        } else {
            previous.next = item;
        }
    }

    public Task(JFrame frame) {
        reNew();
        setBounds(frame.getWidth() / 12, frame.getHeight() * 5 / 14, frame.getWidth() * 3 / 8, frame.getHeight() * 4 / 7);
        setBorder(BorderFactory.createEmptyBorder());
    }
}

