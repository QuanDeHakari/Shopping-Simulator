package PayingState;

import ReadyState.*;
import ShoppingState.*;
import Item.*;
import JFrame.Menu;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import static java.lang.Math.pow;

public class Queue extends JLayeredPane {
    Person[] queue1 = new Person[4];
    Person[] queue2 = new Person[4];
    Person[] queue3 = new Person[4];
    int num1=0, num2=0, num3=0;
    Random rand = new Random();
    ReadyPage readyPage;
    Player player;

    void simulate(JFrame frame, ReadyPage readyPage, shelfList shelfList) {
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
                while (readyPage.status.enthusiasm > 0) {
                    frame.revalidate();
                    frame.repaint();
                    TimeUnit.SECONDS.sleep(1);

                    updateQueue(queue1, frame);
                    updateQueue(queue2, frame);
                    updateQueue(queue3, frame);

                    if (player.time <= 0) {
                        endDay(frame, readyPage, shelfList);
                        return null;
                    }

                    insertRandomCustomers();

                    readyPage.status.enthusiasm -= pow(1.2, readyPage.status.day) / 5;
                    if (readyPage.status.enthusiasm <= 0) {
                        frame.remove(this.getProgress());
                        gameOver(frame);
                        return null;
                    }
                }
                return null;
            }
            private void updateQueue(Person[] queue, JFrame frame) throws InterruptedException {
                queue[0].time--;
                if (queue[0].time == 0) {
                    remove(queue[0]);
                    for (int time = 0; time < 2; time++) {
                        for (int j = 1; j < (queue==queue1?num1:(queue==queue2?num2:num3)); j++) {
                            if (queue[j] != null) {
                                queue[j].setBounds(queue[j].getX(), queue[j].getY()-frame.getHeight()/10, queue[j].getWidth(), queue[j].getHeight());
                                frame.revalidate();
                                frame.repaint();
                            }
                        }
                        TimeUnit.SECONDS.sleep(1);
                    }
                    for (int j = 1; j < (queue==queue1?num1:(queue==queue2?num2:num3)); j++) {
                        if (queue[j] != null) {
                            remove(queue[j]);
                            queue[j - 1] = queue[j];
                            add(queue[j - 1]);
                        }
                    }
                    if(queue==queue1) num1--;
                    else if(queue==queue2) num2--;
                    else num3--;
                }
            }

            private void insertRandomCustomers() {
                if (num1 < 2 && rand.nextInt(10) < 2) {
                    int temp = rand.nextInt(10);
                    if (temp < 2) insert(queue1, new VIP());
                    else insert(queue1, new Member());
                }
                if (num2 < 2 && rand.nextInt(10) < 2) {
                    int temp = rand.nextInt(10);
                    if (temp < 1) insert(queue2, new VIP());
                    else if (temp < 5) insert(queue2, new Member());
                    else insert(queue2, new Customer());
                }
                if (num3 < 2 && rand.nextInt(10) < 2) {
                    int temp = rand.nextInt(10);
                    if (temp < 1) insert(queue3, new VIP());
                    else if (temp < 4) insert(queue3, new Member());
                    else insert(queue3, new Customer());
                }
            }
        };

        worker.execute();
    }
    void endDay(JFrame frame, ReadyPage readyPage, shelfList shelfList) {
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
                frame.remove(Queue.this);
                frame.revalidate();
                frame.repaint();

                Item current = readyPage.task.first;
                while (current != null) {
                    while (current.need > 0) {
                        if (shelfList.cartButton.itemHashTable.getItem(current.ID).have > 0)
                            shelfList.cartButton.itemHashTable.getItem(current.ID).have--;
                        else if(readyPage.bag.itemHashTable.getItem(current.ID).have > 0)
                            readyPage.bag.itemHashTable.getItem(current.ID).have--;
                        else readyPage.status.enthusiasm -= pow(1.2, readyPage.status.day) / 3;
                        current.need--;
                    }
                    current = current.next;
                }

                if (readyPage.status.enthusiasm <= 0) {
                    gameOver(frame);
                    return null;
                }
                for (int i = 0; i < 20; i++) {
                    if(shelfList.cartButton.itemHashTable.getItem(i)!=null)
                        readyPage.bag.itemHashTable.getItem(i).have += shelfList.cartButton.itemHashTable.getItem(i).have;
                }
                readyPage.bag.text();
                readyPage.status.day++;
                readyPage.status.addPoint(rand.nextInt(20));
                readyPage.task.reNew();
                readyPage.updateLabels(readyPage.task);

                readyPage.setEnabled(true);
                readyPage.setVisible(true);
                readyPage.dayLabel.setVisible(true);
                readyPage.enthusiasmLabel.setVisible(true);
                readyPage.budgetLabel.setVisible(true);

                frame.revalidate();
                frame.repaint();
                return null;
            }
        };
        worker.execute();
    }
    void gameOver(JFrame frame){
        ImageIcon BG = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\PayingState\\GAMEOVER.png").getImage().getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH));
        JLabel label = new JLabel();
        label.setIcon(BG);
        label.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        frame.add(label);
        frame.revalidate();
        frame.repaint();
        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        frame.remove(label);
        frame.add(new Menu(frame));
        frame.revalidate();
        frame.repaint();
    }
    void insert(Person[] queue, Person person) {
        int i=0;
       if(queue==queue1) {
           i=num1;
           num1++;
       }
       else if(queue==queue2) {
           i=num2;
           num2++;
       }
       else {
           i=num3;
           num3++;
       }
        while (i > 1 && queue[i - 1].priority < person.priority) {
            queue[i] = queue[i - 1];
            queue[i].setBounds(queue[i].getX(), queue[i].getY() - getHeight() / 5, queue[i].getWidth(), queue[i].getHeight());
            i--;
        }
        switch (i) {
            case 0:
                if(queue==queue1) person.setBounds(getWidth()*6/25, getHeight()/5, person.getWidth(), person.getHeight());
                else if(queue==queue2) person.setBounds(getWidth()*10/25, getHeight()/5, person.getWidth(), person.getHeight());
                else person.setBounds(getWidth()*22/25, getHeight()/5, person.getWidth(), person.getHeight());
                break;
            case 1:
                if(queue==queue1) person.setBounds(getWidth()*6/25, getHeight()*2/5, person.getWidth(), person.getHeight());
                else if(queue==queue2) person.setBounds(getWidth()*10/25, getHeight()*2/5, person.getWidth(), person.getHeight());
                else person.setBounds(getWidth()*22/25, getHeight()*2/5, person.getWidth(), person.getHeight());
                break;
            case 2:
                if(queue==queue1) person.setBounds(getWidth()*6/25, getHeight()*3/5, person.getWidth(), person.getHeight());
                else if(queue==queue2) person.setBounds(getWidth()*10/25, getHeight()*3/5, person.getWidth(), person.getHeight());
                else person.setBounds(getWidth()*22/25, getHeight()*3/5, person.getWidth(), person.getHeight());
                break;
            default:
                if(queue==queue1) person.setBounds(getWidth()*6/25, getHeight()*4/5, person.getWidth(), person.getHeight());
                else if(queue==queue2) person.setBounds(getWidth()*10/25, getHeight()*4/5, person.getWidth(), person.getHeight());
                else person.setBounds(getWidth()*22/25, getHeight()*4/5, person.getWidth(), person.getHeight());
                break;
        }
        queue[i]=person;
        add(person);
        revalidate();
        repaint();
    }
    void addChoice(JFrame frame, ReadyPage readyPage, shelfList shelfList) {
        for (int i = 0; i < 3; i++) {
            if (rand.nextInt(5)<4)
                insert(queue1, rand.nextInt(5)<1?new VIP():new Member());
            if (rand.nextInt(5)<4)
                insert(queue2, rand.nextInt(10)<3?(rand.nextInt(5)<1?new VIP():new Member()):new Customer());
            if (rand.nextInt(5)<4)
                insert(queue3, rand.nextInt(5)<1?(rand.nextInt(5)<1?new VIP():new Member()):new Customer());
        }
        ImageIcon stable = new ImageIcon("D:\\DSA_Project\\src\\ShoppingState\\Exit.png");
        ImageIcon unstable = new ImageIcon("D:\\DSA_Project\\src\\ShoppingState\\ExitPress.png");

        JLabel enterQ1 = new JLabel();
        enterQ1.setIcon(stable);
        enterQ1.setBounds(getWidth()*6/25, getHeight()*4/5, stable.getIconWidth(), stable.getIconHeight());
        add(enterQ1, PALETTE_LAYER);

        JLabel enterQ2 = new JLabel();
        enterQ2.setIcon(stable);
        enterQ2.setBounds(getWidth()*10/25, getHeight()*4/5, stable.getIconWidth(), stable.getIconHeight());
        add(enterQ2, PALETTE_LAYER);

        JLabel enterQ3 = new JLabel();
        enterQ3.setIcon(stable);
        enterQ3.setBounds(getWidth()*22/25, getHeight()*4/5, stable.getIconWidth(), stable.getIconHeight());
        add(enterQ3, PALETTE_LAYER);

        enterQ1.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                enterQ1.setIcon(unstable);
            }
            public void mouseExited(MouseEvent e) {
                enterQ1.setIcon(stable);
            }
            public void mousePressed(MouseEvent e) {
                enterQ1.setEnabled(false);
                enterQ2.setEnabled(false);
                enterQ3.setEnabled(false);
                enterQ1.setVisible(false);
                enterQ2.setVisible(false);
                enterQ3.setVisible(false);
                insert(queue1, player);
                simulate(frame, readyPage, shelfList);
            }
        });
        enterQ2.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                enterQ2.setIcon(unstable);
            }
            public void mouseExited(MouseEvent e) {
                enterQ2.setIcon(stable);
            }
            public void mousePressed(MouseEvent e) {
                enterQ1.setEnabled(false);
                enterQ2.setEnabled(false);
                enterQ3.setEnabled(false);
                enterQ1.setVisible(false);
                enterQ2.setVisible(false);
                enterQ3.setVisible(false);
                insert(queue2, player);
                simulate(frame, readyPage, shelfList);
            }
        });
        enterQ3.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                enterQ3.setIcon(unstable);
            }
            public void mouseExited(MouseEvent e) {
                enterQ3.setIcon(stable);
            }
            public void mousePressed(MouseEvent e) {
                enterQ1.setEnabled(false);
                enterQ2.setEnabled(false);
                enterQ3.setEnabled(false);
                enterQ1.setVisible(false);
                enterQ2.setVisible(false);
                enterQ3.setVisible(false);
                insert(queue3, player);
                simulate(frame, readyPage, shelfList);
            }
        });
    }
    public Queue(JFrame frame, ReadyPage readyPage, shelfList shelfList) {
        this.readyPage=readyPage;
        player=new Player(readyPage.status);

        setLayout(null);
        ImageIcon BG = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\PayingState\\Queuing.png").getImage().getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH));
        JLabel label = new JLabel(BG);
        label.setBounds(frame.getBounds());
        add(label, JLayeredPane.FRAME_CONTENT_LAYER);
        setBounds(frame.getBounds());

        addChoice(frame, readyPage,shelfList);
    }
}
abstract class Person extends JLabel {
    int time;
    int priority;
}
class Customer extends Person {
    Customer() {
        time = new Random().nextInt(7)+2;
        priority = 0;
        ImageIcon image=new ImageIcon("D:\\DSA_Project\\src\\PayingState\\Customer.png");
        setIcon(image);
        setBounds(0, 0, image.getIconWidth(), image.getIconHeight());
    }
}
class Member extends Person {
    Member() {
        time = new Random().nextInt(7)+3;
        priority = 1;
        ImageIcon image=new ImageIcon("D:\\DSA_Project\\src\\PayingState\\Member.png");
        setIcon(image);
        setBounds(0, 0, image.getIconWidth(), image.getIconHeight());
    }
}
class VIP extends Person {
    VIP() {
        time = new Random().nextInt(4)+4;
        priority = 2;
        ImageIcon image=new ImageIcon("D:\\DSA_Project\\src\\PayingState\\VIP.png");
        setIcon(image);
        setBounds(0, 0, image.getIconWidth(), image.getIconHeight());
    }
}
class Player extends Person {
    Player(Status status) {
        time = 5;
        if (status.VIP) priority = 2;
        else if(status.mem) priority = 1;
        else priority = 0;
        ImageIcon image=new ImageIcon("D:\\DSA_Project\\src\\PayingState\\Player.png");
        setIcon(image);
        setBounds(0, 0, image.getIconWidth(), image.getIconHeight());
    }
}
