package ReadyState;

import Item.Task;

import javax.swing.*;
import java.awt.*;

public class ReadyPage extends JPanel {
    private ImageIcon bgImage;
    private JLabel bgLabel = new JLabel();
    public Status status;
    public JLabel dayLabel;
    public JLabel enthusiasmLabel;
    public JLabel budgetLabel;
    public Task task;
    public Bag bag;

    public ReadyPage(JFrame frame) {
        setLayout(null);
        setBounds(0, 0, frame.getWidth(), frame.getHeight());

        status = new Status();

        dayLabel = new JLabel();
        dayLabel.setFont(new Font("Lucida Handwriting", Font.BOLD, 58));
        dayLabel.setBounds(100, 0, frame.getWidth() / 4, frame.getHeight() * 2 / 21);
        add(dayLabel);

        enthusiasmLabel = new JLabel();
        enthusiasmLabel.setFont(new Font("Lucida Handwriting", Font.BOLD | Font.ITALIC, 58));
        enthusiasmLabel.setForeground(new Color(17, 249, 237));
        enthusiasmLabel.setBounds(50, frame.getHeight() * 2 / 21, frame.getWidth() / 4, frame.getHeight() * 4 / 21);
        add(enthusiasmLabel);

        budgetLabel = new JLabel();
        budgetLabel.setFont(new Font("Lucida Handwriting", Font.BOLD | Font.ITALIC, 58));
        budgetLabel.setForeground(new Color(17, 249, 237));
        budgetLabel.setBounds(frame.getWidth() * 3 / 4, frame.getHeight() * 2 / 21, frame.getWidth() / 4, frame.getHeight() * 4 / 21);
        add(budgetLabel);

        GoButton goButton = new GoButton(frame, this);
        add(goButton);

        task = new Task(frame);
        add(task);

        bag = new Bag(frame);
        add(bag);

        bgImage = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\ReadyState\\ReadyBG.png").getImage().getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH));
        bgLabel.setIcon(bgImage);
        bgLabel.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        add(bgLabel);

        updateLabels(task);
    }
    public void updateLabels(Task task) {
        dayLabel.setText("Day: " + status.day);
        enthusiasmLabel.setText("<html>Enthusiasm<br>&nbsp;&nbsp;" + Math.round(status.enthusiasm) + "</html>");
        status.getMoney(task);
        budgetLabel.setText("<html><div style='text-align: right;'>Budget<br>" + (double) Math.round(status.budget * 100) / 100 + "&nbsp;&nbsp;</html>");
    }
}

