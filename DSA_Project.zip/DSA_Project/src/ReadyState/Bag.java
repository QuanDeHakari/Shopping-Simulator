package ReadyState;

import Item.itemHashTable;

import javax.swing.*;
import java.awt.*;

public class Bag extends JScrollPane {
    public itemHashTable itemHashTable = new itemHashTable();
    public JTextArea textArea = new JTextArea();
    void reNew() {
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setFont(new Font("Lucida Handwriting", Font.BOLD | Font.ITALIC, 29));
        textArea.setOpaque(false);

        text();
        add(textArea);

        setViewportView(textArea);
        setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        setOpaque(false);
        getViewport().setOpaque(false);
    }
    public void text(){
        StringBuilder textBuilder = new StringBuilder();
        for(int i=0; i<itemHashTable.size; i++){
            textBuilder.append(itemHashTable.addText(i));
        }
        textArea.setText(textBuilder.toString());
    }

    public Bag(JFrame frame) {
        reNew();
        setBounds(frame.getWidth()*7/12, frame.getHeight()*5/14, frame.getWidth()*3/8, frame.getHeight()*4/7);
        setBorder(BorderFactory.createEmptyBorder());
    }
}
