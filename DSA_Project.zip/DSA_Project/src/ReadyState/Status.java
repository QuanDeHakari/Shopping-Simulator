package ReadyState;

import Item.Item;
import Item.Task;
import Item.itemHashTable;

import java.util.Random;

public class Status {
    public int day;
    public double budget;
    public double enthusiasm;
    public boolean VIP;
    public boolean mem;
    double memPoint=0, VIPPoint=0;
    public Status(){
        day=1;
        budget=0;
        enthusiasm=200;
        VIP=false;
        mem=false;
    }
    public void getMoney(Task task){
        Item current = task.first;
        while(current!=null){
            budget+=current.price+new Random().nextDouble(2);
            current=current.next;
        }
    }
    public void setmem(double point){
        memPoint+=point;
        if(memPoint>100){
            mem=true;
        }
    };
    public void setVIP(double point){
        VIPPoint+=point;
        if(VIPPoint>300){
            VIP=true;
        }
    }
    public void addPoint(double point){
        if(VIP) return;
        else if(mem) setVIP(point);
        else setmem(point);
    }
}
