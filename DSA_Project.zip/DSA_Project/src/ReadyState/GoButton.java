package ReadyState;

import ShoppingState.shelfList;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GoButton extends JLabel{
    public GoButton(JFrame frame, ReadyPage readyPage){
        ImageIcon stable = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\ReadyState\\Go.png").getImage().getScaledInstance(frame.getHeight()*2/21, frame.getHeight()*2/21, Image.SCALE_SMOOTH));
        ImageIcon unstable = new ImageIcon(new ImageIcon("D:\\DSA_Project\\src\\ReadyState\\GoPress.png").getImage().getScaledInstance(frame.getHeight()*2/21, frame.getHeight()*2/21, Image.SCALE_SMOOTH));
        setIcon(stable);
        setBounds(frame.getWidth()-stable.getIconWidth()-50, 0, stable.getIconWidth(), stable.getIconHeight());
        addMouseListener(new MouseAdapter(){
            public void mouseEntered(MouseEvent e){
                setIcon(unstable);
            }
            public void mouseExited(MouseEvent e){
                setIcon(stable);
            }
            public void mousePressed(MouseEvent e){
                readyPage.setEnabled(false);
                readyPage.setVisible(false);
                shelfList shelf = new shelfList(frame, readyPage);
            }
        });
    }
}
